function Hold=HoldByOdds(Hold,Odds)
[x,y]=size(Hold);
for i=1:x
    for j=1:y
       if rand>Odds
           Hold(i,j)=0;
       end
    end
end