function PathPlot(node,CityNum,index,EachBest);


for i=1:CityNum
   NowBest(i,:)=node((EachBest(i,index)),:);
end
NowBest(CityNum+1,:)=NowBest(1,:);
plot(node(:,1),node(:,2),'*');
line(NowBest(:,1),NowBest(:,2));
grid on;