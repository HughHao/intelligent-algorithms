fun = @(x)x(1)*exp(-norm(x)^2);
%
lb = [-10,-15];
ub = [15,20];
%
rng default  % For reproducibility
nvars = 2;
x = particleswarm(fun,nvars,lb,ub)
fsurf(@(x,y)x.*exp(-(x.^2+y.^2)))