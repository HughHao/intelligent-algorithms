function []=draw_fig2(X,w,T,Arr_zbest)
x = X(6:34);
Core_index=x;
%% ����ÿ��IP�˵Ŀ�ʼ����ʱ��
D=cell(29,1);
for m=1:29
    D{m}=zeros(1,2);
end
w=w(x(:));
T=T(x(:));
[Y,array] = fitness(w,T,X,Arr_zbest);
for i = 1:29
    x(i)=Arr_zbest(i);
    if i>=1 && i<=5
        D{i}(1,1)=0;
        D{i}(1,2)=T(i);
    else
        D{i}(1,1)=array(x(i-5));
        array(x(i))=array(x(i-5))+T(i);
        D{i}(1,1) = array(x(i));
    end
end
T_MAX=Y;
%% ��ͼ
clf
w=0.8; % ��������
set(gcf,'color','w');
A=cell(29,1);

for jj=1:29
    A(jj)={[x(jj) Core_index(jj) D{jj}(1,1) D{jj}(1,2)]};
end
for ii=1:29
    B=A{ii};
    p=B(1,[3 3 4 4]);
    y=B(1,1)+[-w/2 w/2 w/2 -w/2];
    patch('xdata',p,'ydata',y,'facecolor','none','edgecolor','k');
    text(B(1,3),B(1,1),num2str(B(1,2)));
end
xlabel('processing time');
ylabel('TAM_numder');
axis([0  T_MAX+100 0.5 5+0.5]);
set(gca,'Box','on')