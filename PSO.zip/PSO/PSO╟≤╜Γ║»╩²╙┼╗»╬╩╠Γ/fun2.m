function f=fun2(pop)
f=pop(1)*(-5)-4*pop(2)-6*pop(3);
end