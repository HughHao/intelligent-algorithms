function  newChrom  =select( Chrom,fitV )
[NIND,amount]=size(Chrom);
newChrom = zeros(NIND,amount);
for i=1:NIND
    r=rand;
    for j=1:NIND
        if j>1
            if fitV(j-1)<=r&&r<fitV(j)
                newChrom(i,:) = Chrom(j,:);
                break;
            end
        else
            if r<fitV(j)
                newChrom(i,:) = Chrom(j,:);
                break;
            end
        end
    end
end
