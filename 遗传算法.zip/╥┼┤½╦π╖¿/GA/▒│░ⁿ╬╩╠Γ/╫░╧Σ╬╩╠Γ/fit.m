function  fitV = fit( obj )
[NIND]=length(obj);
objSum=0;
for i=1:NIND
    objSum=objSum+obj(i);
end
% for i=1:NIND
%     if i>1
%         fitV(i)=fitV(i-1)+obj(i)/objSum;
%     else
%         fitV(i)=obj(i)/objSum;
%     end
% end

fitV=cumsum(obj/objSum);