function [objV,bestobj,bestChrom] = obj(Chrom,bill)
[NIND,amount]=size(Chrom);
for i=1:NIND
    objV(i)=0;
    for j=1:amount
        objV(i)=objV(i)+Chrom(i,j)*bill(j,1);
    end
end
[bestobj,index]=max(objV);
bestChrom=Chrom(index,:);