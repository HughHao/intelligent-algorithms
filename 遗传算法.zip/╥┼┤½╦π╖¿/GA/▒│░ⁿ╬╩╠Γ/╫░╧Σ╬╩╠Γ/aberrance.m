function  newChrom  = aberrance( Chrom,MUTR )
[NIND,amount] = size(Chrom);
newChrom = zeros(NIND,amount);
for i=1:NIND
    newChrom(i,:) = Chrom(i,:);
    if rand<MUTR
        p = randi(amount);
        v = Chrom(i,p);
        if v==1
            newChrom(i,p) = 0;
        else
            newChrom(i,p) = 1;
        end
    end
end

