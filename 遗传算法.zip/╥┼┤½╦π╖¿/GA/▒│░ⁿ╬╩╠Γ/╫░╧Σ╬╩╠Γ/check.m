function [ Chrom ,objV,weight] = check( Chrom,bill,maxWeight )
[NIND,amount]=size(Chrom);
objV=obj(Chrom,bill);
for i=1:NIND
    weight(i)=0;
    for j=1:amount
        weight(i)=weight(i)+Chrom(i,j)*bill(j,2);
    end
end
for i=1:NIND
    while weight(i)>maxWeight
        temp = Chrom(i,:);
        index = find(temp);
        a = length(index);
        b = randi(a);%0-a֮����������
        p = index(b);
        objV(i)=objV(i)-bill(p,1);
        weight(i)=weight(i)-bill(p,2);
        Chrom(i,p)=0;
    end
end

