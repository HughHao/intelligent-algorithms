function [Chrom, objV] = ReplaceWorse(Chrom, bestChrom, objV)
for i =1:2:size(Chrom,1)
    %if objV<bestobj
    Chrom(i,:)=bestChrom;
    %objV=bestobj;
    %end
end
end