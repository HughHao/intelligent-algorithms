clc;clear;
%C=[220,208,198,192,180,180,165,162,160,158,155,130,125,122,120,118,115,110,105,101,100,100,                                                                    98,96,95,90,88,82,80,77,75,73,72,70,69,66,65,63,60,58,56,                50,30,20,15,10,8,5,3,1]
%W=[80,  82, 85, 70,  72,70, 66, 50, 55, 25, 50, 55,40,  48, 50,32,  22,60, 30,  32, 40,38,                                                                     35,32,25,28,30,22,50,30,45,30,60,50,20,65,20,25,30,10,20,                25,15,10,10,10,4,4,2,1]
bill=[220,80;208,82;198,85;192,70;180,72;180,70;165,66;162,50;160,55;158,25;155,50;130,55;125,40;122,48;120,50;118,32;115,22;110,60;105,30;101,32;100,40;100,38;98,35;96,32;95,25;90,28;88,30;82,22;80,50;77,30;75,45;73,30;72,60;70,50;69,20;66,65;65,20;63,25;60,30;58,10;56,20;50,25;30,15;20,10;15,10;10,10;8,4;5,4;3,2;1,1];
%bill=[10,15;15,25;20,35;25,45;30,55;35,70];
NIND=50;
maxGen=500;
maxWeight = 1000;
[amount,~] = size(bill);
XOVR=0.6;  %������
MUTR=0.1;  %������
trace=zeros(2,maxGen);
%��ʼ����Ⱥ
Chrom = zeros(NIND,amount);
for i=1:NIND
    weight(i)=0;
    for j=1:amount
        Chrom(i,j)=randi(2)-1;
        weight(i)=weight(i)+Chrom(i,j)*bill(j,2);
    end
    while weight(i)>maxWeight
        weight(i)=0;
        for j=1:amount
            Chrom(i,j)=randi(2)-1;
            weight(i)=weight(i)+Chrom(i,j)*bill(j,2);
        end
    end
end
%�����ʼ��ȺĿ�꺯��ֵ
objV=obj(Chrom,bill);
%ѭ��
gen=0;
while gen<maxGen
    %������Ӧ���ۼƸ���
    fitV=fit(objV);
    %ѡ��
    Chrom=select(Chrom,fitV);
    %����
    Chrom = across (Chrom,XOVR);
    %���Ϸ���
    [Chrom,objV,weight] = check(Chrom,bill,maxWeight);
    %����
    Chrom = aberrance (Chrom,MUTR);
    %���Ϸ���
    [Chrom,objV,weight] = check(Chrom,bill,maxWeight);
    gen = gen+1;
    trace(1,gen) = max(objV);
    trace(2,gen) = mean(objV);
end
figure(1)
plot(trace(1,:));
hold on;
plot(trace(2,:),'-.');
grid;
legend('����ֵ�ı仯','��ֵ�ı仯');
optimalValue=max(trace(1,:));