function  newChrom  = across( Chrom,XOVR )
[NIND,amount] = size(Chrom);
newChrom = zeros(NIND,amount);
for i=1:2:NIND
    r=randi(amount);
    while r==1
        r=randi(amount);
    end
    if XOVR>rand
        for j=1:amount
            if j<r
                newChrom(i,j) = Chrom(i,j);
                newChrom(i+1,j) = Chrom(i+1,j);
            else
                newChrom(i,j) = Chrom(i+1,j);
                newChrom(i+1,j) = Chrom(i,j);
            end
        end
    else
            newChrom(i,:) = Chrom(i,:);
            newChrom(i+1,:) = Chrom(i+1,:);
    end       
end

