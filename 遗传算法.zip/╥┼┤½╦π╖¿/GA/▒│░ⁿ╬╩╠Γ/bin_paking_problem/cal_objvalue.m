function [objvalue,newpop] = cal_objvalue(pop,V0,v)
[px,py]=size(pop);newpop=ones(px,py);objvalue=ones(px,1);
for i=1:px
    v1=v(pop(i,:)==1);objvalue(i)=sum(v1);
if objvalue(i)>V0
    for j=1:py
        index=round(py*rand);
        if index<=0
            index=1;
        end
        if pop(i,index)==1
            pop(i,index)=0;v2=v(pop(i,:)==1);objvalue(i)=sum(v2);
            if objvalue(i)<=V0
            break
            end
        end    
    end     
newpop(i,:)=pop(i,:);
end
end