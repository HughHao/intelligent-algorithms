function pop=initpop(popsize,chromlength)
pop = round(rand(popsize,chromlength));
[px,py]=size(pop);
for i=1:px
    for j=1:py
        if pop(i,j)<0
            pop(i,j)=0;
        end
    end
end