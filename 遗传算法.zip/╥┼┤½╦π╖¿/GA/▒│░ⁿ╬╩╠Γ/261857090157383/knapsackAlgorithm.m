%0-1 Knapsack Problem in Matlab
%algorito.com

clear; close all; clc;

%% input - feel free to change it
knapsack = 100; %size of knapsack
weight = [12 8 5 5 6 4 3 8 9 23 5 6 7 6 3 5 8 3 8 9 8 9 7]; %weight of items
worth =  [40 35 17 19 43 60 25 76 45 32 19 20 47 34 54 42 43 54 29 30 45 22 33]; %worth of items

%% knapstack
%add the "zero item" to allow single items to be taken in the loop
weight = [weight 0];
worth =  [worth 0];

s = length(weight);
solutions = zeros(1,s+2);

for ii=1:s % available items
    items(ii,:) = zeros(1,s+2);
    items(ii,ii) =1;
    items(ii,s+1) = worth(ii);
    items(ii,s+2) = weight(ii);
end
solutions = items;%s*(s+2)����

proposedOptimal = [];%���н�
for kz = 1:knapsack %all sizes from minimal weight to knapsack size
    %pick a combination of solution as the new solution

    %(double loop could be improved)
    for jj = 1:size(solutions,1) %consider all solutions
        for kk = 1:size(solutions,1) %in pairs
            if ~sum(solutions(jj,1:end-2).*solutions(kk,1:end-2)) %never take an item twice
                %make sure weight sum does not exceed knapsak
                if (solutions(jj,end) + solutions(kk,end))<=kz
                    %propose an optimal solution
                    proposedOptimal(end+1,:) = solutions(jj,:) + solutions(kk,:);
                end
            end
        end
    end

    if ~isempty(proposedOptimal) %if solution were proposed
        %pick THE optimal solution from proposed solutions
        temp = find(proposedOptimal(:,end-1) == max(proposedOptimal(:,end-1))); temp = temp(1);
        %remember that solution in the array
        solutions(end+1,:) = proposedOptimal(temp,:);
    end
    proposedOptimal = [];
end


%% output - print results
fprintf('\nOptimal Items:');
for ii=1:size(solutions(end,:),2)-3 %ignore zero items
    if solutions(end,ii)==1 %if the item is taken
        jj = solutions(end,ii);
        fprintf('\n  Take item number %d with weight %d which is worth %d.',ii, weight(ii), worth(ii));
    end
end
fprintf('\nTotal weight of items %d, total worth %d \n\n',solutions(end,end), solutions(end,end-1) );
