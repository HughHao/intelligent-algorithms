function [fit,chrome]=fitness_fcn(chf,w,p,popu_size)
contain=1000;
[px,py]=size(chf);
for i=1:px
    w_s=chf(i,:)*w; 
    more = w_s-contain;
    if more>0
       for j=1:py
           if chf(i,j)>0 
               chf(i,j)=0;
               more = chf(i,:)*w-contain;
               if more<=0
                   break
               end
           end
        end
     end
%        fit(i)=chf(i,:)*p-1000*(w_s-1000);
%        if fit(i)<0
%            fit(i)=0;
%        end       
   fit(i)=chf(i,:)*p;
   chrome(i,:)=chf(i,:);
end