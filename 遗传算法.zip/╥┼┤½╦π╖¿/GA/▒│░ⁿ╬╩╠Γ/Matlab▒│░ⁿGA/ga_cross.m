function newpop=ga_cross(pop,~)
pc=0.85;
% for i=1:2:(popu_size-1)
%     a=rand;
%     if a<pc
%         cross_posi=round(a*50);
%         if (cross_posi==0) || (cross_posi==1)
%             continue
%         end
%         for j=cross_posi:50
%             if i<(popu_size-1)
%             chrome_2([i,i+2],[cross_posi,50])=chrome_2([i+2,i],[cross_posi,50]);
%             else
%                 continue
%             end
%         end
%     end
[px,py] = size(pop);
newpop = ones(size(pop));
for i = 1:2:px-1
    if(rand<pc)
        cpoint = round(rand*py);
        newpop(i,:) = [pop(i,1:cpoint),pop(i+1,cpoint+1:py)];
        newpop(i+1,:) = [pop(i+1,1:cpoint),pop(i,cpoint+1:py)];
    else
        newpop(i,:) = pop(i,:);
        newpop(i+1,:) = pop(i+1,:);
    end
end