function fitnesssum=fit_sum(fit,popu_size)
fitnesssum=cumsum(fit);
[px,py]=sort(fit);
% for i=1:px
%     if i==1
%         fitnesssum(i) = fit(1);    
%     else
%         fitnesssum(i) = fit(i-1) + fit(i);
%     end
% end
