function chf=first_gen(popu_size)
chf=round(rand(popu_size,50));
% for i = 1:popu_size
%     for j=1:50
%         if chf(i,j)<=0
%             chf(i,j)=0;
%         end
%     end
% end

   