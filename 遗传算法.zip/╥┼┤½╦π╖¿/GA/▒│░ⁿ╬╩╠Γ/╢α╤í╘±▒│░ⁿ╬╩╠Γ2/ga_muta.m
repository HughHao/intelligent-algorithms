function newpop= ga_muta(pop,popu_size)
% muta_rate=0.25;
% for i=1:popu_size
%     if rand < muta_rate
%         muta_posi = round(rand*50);  % ����λ��
%         if muta_posi == 0
%             % ������λ��Ϊ0��������
%             continue;
%         end
%         chrome(i,muta_posi) = 1 - chrome(i, muta_posi);
%     end
% end
% chrome_m=chrome;
pm=0.05;
[px,py] = size(pop);
newpop = ones(size(pop));
for i = 1:px
    if(rand<pm)
        mpoint = round(rand*py);
        if mpoint <= 0
            mpoint = 1;
        end
        newpop(i,:) = pop(i,:);
        if newpop(i,mpoint) == 0
            newpop(i,mpoint) = 1;
        elseif newpop(i,mpoint) == 1
            newpop(i,mpoint) = 0;
        end
    else
        newpop(i,:) = pop(i,:);
    end
end