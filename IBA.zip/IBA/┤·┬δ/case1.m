%% ��ջ���
clear
clc
close all
%% ����ͼ��
% figure(1)
[x1,x2]=meshgrid(-3:3,-5:5);
y=0.8./(x1.^2+x2.^2+1)+0.2*(x1.^2+3*x2.^2+1);
% subplot(1,2,1); mesh(x1,x2,y);
% subplot(1,2,2); surf(x1,x2,y);
% surf(x1,x2,y);xlabel('x1-axis'); ylabel('x2-axis'); zlabel('y-axis');
%% 1.��ʼ��
tic
A0=100;% P0 ��Ⱥ��ʼ��ģ
r0=0.01;% r0 ��Ⱥ��ʼ������
K=10000;% K ����������
K0=0.95;% K0 ͣ��׼��
t=1;% t ʱ��
%% 2.��ʼ��
sc=[-3,3;-5,5];
X0=[sc(1,1)+rand*(sc(1,2)-sc(1,1)),sc(2,1)+rand*(sc(2,2)-sc(2,1))];
y0=0.8/(X0(1)^2+X0(2)^2+1)+0.2*(X0(1)^2+3*X0(2)^2+1);
fun(t)=y0;
x(t)=X0(1);
z(t)=X0(2);
% fprintf('��ʼx --->>%5.4f\n',x1);
% fprintf('��ʼ����ֵ --->>%5.4f\n',f1);
%% 3.�ڵ�ǰ��Ⱥˮƽ��Ѱ���½�
A=A0;r=r0;
while A<K
    L=round(log(K/A));
    A=K*A0*exp(r*t)/(K+A0*(exp(r*t)-1));
    nn=randperm(2);
    ze=rand;
    if ze>0.5
        ze=-1;
    else
        ze=1;
    end
%     P=K/(1+(K/P-1)*exp(-r0*t));
    r=r0*(1-A/K);
    t=t+1;
    X=zeros(L,2);
    Y=zeros(L,1);
    for k=1:L
        X(k,nn(1))=X0(nn(1))+ze*rand;
        if X(k,nn(1))>sc(nn(1),2)
            X(k,nn(1))=sc(nn(1),2);
        elseif X(k,nn(1))<sc(nn(1),1)
            X(k,nn(1))=sc(nn(1),1);
        end
        X(k,nn(2))=X0(nn(2));
        Y(k)=0.8/(X(k,1)^2+X(k,2)^2+1)+0.2*(X(k,1)^2+3*X(k,2)^2+1);
        delta=Y(k)-y0;
        if delta<0
            X0=X(k,:);
            y0=Y(k,:);
        else
            W=-delta/(A*r);
            if W>rand
                X0=X(k,:);
                y0=Y(k,:);
            end
        end
    end
    x(t)=X0(1);
    z(t)=X0(2);
    fun(t)=y0;
end
toc
fprintf('���� X Ϊ --->>%5.7f\n',X0);
fprintf('���պ���ֵ --->>%5.7f\n',y0);
figure(2)
plot3(x(:),z(:),fun(:),'k*');
xlabel('x1-axis'); ylabel('x2-axis'); zlabel('y-axis');
grid on
% title('��������');
