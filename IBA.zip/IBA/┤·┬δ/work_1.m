clear
clc
A=[72	85
80	90
78	82
65	76
91	96
77	75
62	69
72	70
67	65
77	85
91	95
88	96
90	97
81	89
72	71
55	60
79	75
86	95
89	91
45	30
65	35
74	81
85	92
85	95
47	30
92	95
87	95
66	60
76	35
70	70
95	98
44	60
75	85
78	80
77	80
69	35
82	90
81	75
73	70
87	92];
x_mean=mean(A(:,1));
y_mean=mean(A(:,2));
%sum_mu=sum((A(:,1)-x_mean)*(A(:,2)-y_mean));
for i=1:length(A(:,1))
    i_cha(i)=(A(i,1)-x_mean)*(A(i,2)-y_mean);
    i2_cha(i)=(A(i,1)-x_mean)^2;
end
sum_i=sum(i_cha);
sum_i2=sum(i2_cha);
b=sum_i/sum_i2;
a=y_mean-b*x_mean;
%disp(['y=',num2str(b),'*x+(',num2str(a),')'])
distance=zeros(length(A(:,1))-1,length(A(:,1)));
for j=1:length(A(:,2))
    distance(1,j)=abs(A(j,1)*a-A(j,2)+b)/(sqrt(a^2+1));
end
value=zeros(length(A(:,1))-1,1);
for w=1:length(distance(1,:))
    if distance(1,w)>0

   m(w)=distance(1,w);
    end
end
%mean_distance=mean(m);
[value(1),index]=max(m);
for k=1:length(A(:,1))-1

    if index<length(A(:,1)) && index>=2
        %X=[A(1:index-1),A(index+1:length(A(:,1)))];
        %Y=[A(1:index-1,2),A(index+1:length(A(:,1)),2)];
        A1=A(1:index-1,:);
        A2=A((index+1:length(A(:,1))),:);
        A=[A1
            A2];
        %A=[X',Y];
    elseif index==1
        A=A(2:length(A(:,1)),:);
       % X=A(1:index-1);
        %Y=A(1:index-1,2);
    else
        A=A(1:length(A(:,1))-1,:);
        %A=[X',Y];
    end 
  
    
x_mean=mean(A(:,1));
y_mean=mean(A(:,2));
%sum_mu=sum((A(:,1)-x_mean)*(A(:,2)-y_mean));
for i=1:length(A(:,1))
    i_cha(i)=(A(i,1)-x_mean)*(A(i,2)-y_mean);
    i2_cha(i)=(A(i,1)-x_mean)^2;
end
sum_i=sum(i_cha);
sum_i2=sum(i2_cha);
b=sum_i/sum_i2;
a=y_mean-b*x_mean;
for j=1:length(A(:,1))
    distance(k,j)=abs(A(j,1)*b-A(j,2)+a)/(sqrt(b^2+1));
end
p=zeros(length(A(:,1)),1);
for w=1:length(p)
    if distance(k,w)>0

   p(w)=distance(k,w);
    end
end
mean_distance=mean(p);
[value(k),index]=max(p);
disp(['��',num2str(k),'����','y=',num2str(b),'*x+(',num2str(a),') ','������:',num2str(value(k))])
disp(['�޳��ĵ㣺(',num2str(A(index,1)),',',num2str(A(index,2)),')'])
%disp(['��',num2str(k),'��������:',num2str(value(k))])
%if k>=2&&value(k-1)-value(k)<3
if value(k)-mean_distance<10
    break
end
end 
for j=1:length(A(:,2))
    distance(k,i)=abs(A(i,1)*b-A(i,2)+a)/(sqrt(b^2+1));
end
q=zeros(length(A(:,1)),1);
for w=1:length(distance(k,:))
    if distance(k,w)>0

   q(w)=distance(k,w);
    end
end
mean_distance=mean(q);
[value(k),index]=max(q);
disp(['���մ���','y=',num2str(b),'*x+(',num2str(a),') ','ƽ������:',num2str(mean_distance)])
%disp(num2str(sum(distance(k,:))/length(A(:,1))))
figure(1)
plot(value(1:k))
xlabel('����');
ylabel('������')
title('������仯����');
legend('down');
%legend('sin(t)','e^{-x}');
figure(2)
plot(A(:,1),A(:,2),'k*')
hold on
x1=30:0.05:100;
y1=b*x1+a;
plot(x1,y1,'k')
xlabel('Xֵ');
ylabel('Yֵ')
title('����λ�ü����ֱ��ͼ');
% legend('down');