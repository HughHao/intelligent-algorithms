clear
clc
close all
W=[80	82	85	70	72	70	66	50	55	25	50	55	40	48	50	32	22	60	30	32	40	38	35	32	25	28	30	22	50	30	45	30	60	50	20	65	20	25	30	10	20	25	15	10	10	10	4	4	2	1];
P=[220	208	198	192	180	180	165	162	160	158	155	130	125	122	120	118	115	110	105	101	100	100	98	96	95	90	88	82	80	77	75	73	72	70	69	66	65	63	60	58	56	50	30	20	15	10	8	5	3	1];
L=length(W);
P_W=zeros(1,L);
for l=1:L
    P_W(l)=P(l)/W(l);
end
% paixu=fliplr(sort(p_w));
paixu=sort(P_W,'descend');
con_w=1000;
% total_w=sum(w);
chosen=zeros(1,L);
w_2=zeros(1,L);
p_2=zeros(1,L);
for w=1:L
    for p=1:L
        if P_W(p)==paixu(w)
            chosen(p)=1;
            w_2(w)=W(p);
            p_2(w)=P(p);
        end
    end
     if sum(w_2)>con_w
         w_2(w)=0;
         p_2(w)=0;
         break;
     end
end
% K=length(w_2);
init_p=sum(p_2);
init_w=sum(w_2);
% sum_w=cumsum(w);
% for l=2:L
%     k=l;
%     sum_w(k)=sum_w(l-1)+w(l);
%     if sum_w(k)>con_w
%         k=k-1;
%         break
%     end
% end
out_iter=500;
% in_iter=100;
% in_max=max(p_w(1:k));
% in_min=min(p_w(1:k));
for k=length(w_2)+1:L
    extra_space=con_w-init_w;
    if W(k)<=extra_space
         chosen(k)=1;
         init_p=init_p+P(k);
         init_w=init_w+W(k);
    end
end
mono=sort(randperm(50));
%mono(chosen==1)
fprintf('��ʼ��Ʒ��')
disp(mono(chosen==1))
% init_p
fprintf('��ʼ��Ʒ�ܼ�ֵ��%5.0f\n',init_p)
fprintf('��ʼ��Ʒ��������%5.0f\n',init_w)
range_p=init_p*ones(1,out_iter);
for out=1:out_iter
    w_1(out,:)=w_2;
    p_1(out,:)=p_2;
    chosen_1(out,:)=chosen;
        for choose=1:length(chosen_1(out,:))
            if chosen_1(out,choose)==1
                chosen_1(out,choose)=0;
                w_1(out,choose)=0;
                p_1(out,choose)=0;
                break
            end
        end
        init_w1(out)=sum(w_1(out,:));
        init_p1(out)=sum(p_1(out,:));
        for k=length(w_1(out,:))+1:L
            extra_space=con_w-init_w1(out);
            if W(k)<=extra_space
                 chosen_1(out,k)=1;
                 w_1(out,k)=W(k);
                 p_1(out,k)=P(k);
                 init_p1(out)=sum(p_1(out,:));
                 init_w1(out)=sum(w_1(out,:));
            end
        end
%         range_p(out)=init_p1(out);
    
end
plot(init_p1(:))