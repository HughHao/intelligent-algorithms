function qianzhipingheng()
xielv=15.89;
k=300;
q=5;
delta=ones(k,1)*3;
x=[1 3 8 6 4];
y=[1 4 9 -3 -8];
for i=1:q
    x0=sum(x)/q;
    y0=sum(y)/q;
end
m=min(x);n=max(x);
M=min(y);N=max(y);
jieju=zeros(k,1)+y0-xielv*x0;
c=m-1:0.1:n+1;
v=xielv*c+jieju(1);
figure(7)
plot(c,v,'-');
d=zeros(q,1);
D=zeros(k,1);
for i=1:q
    d(i)=sqrt((xielv*x(i)-y(i)+jieju(1)).^2/(xielv^2+1));
end
D(1)=sum(d);
t=2;
while t>=2&&t<=k
    jieju(t)=jieju(t-1)+delta(t-1);
     for i=1:q
    d(i)=sqrt((xielv*x(i)-y(i)+jieju(t)).^2/(xielv^2+1));
    text(x(i),y(i),'o');
    text(x(i),y(i)*0.9,['(','',int2str(x(i)),'��','',int2str(y(i)),')']);
    end
     D(t)=sum(d);
     if D(t)<D(t-1)
         delta(t)=delta(t-1);
     else
         delta(t)=-1*delta(t-1)/1.1;
     end
     c=m-1:0.1:n+1;
       v=xielv*c+jieju(t);
       figure(6)
       plot(c,v,'b-');
       text(x0,y0,'*');
       text(x0,y0+1,['y=','',num2str(xielv),'x','+','(','',num2str(jieju(t)),')']);
       title('Shortest distance linear search process');
        set(gca,'XLim',[m-3,n+3]); 
        set(gca,'YLim',[M-3,N+3]);
        hold off
       pause(0.05);
       t=t+1;
end
hold on
figure(4)
   plot(jieju(:),'k-');
   title('the regression of intercept');
   legend('IBA-Intercept1','location','northeast');
  xlabel('iterations ');
  ylabel('value');
  text(k/2,jieju(k),['Intercept=',num2str(jieju(k))]);
  hold off
  hold on
figure(5) 
  plot(D(:),'k-');
  title('Distance variation map on intercept');
  legend('IBA-Distance','location','northeast');
  xlabel('iterations ');
  ylabel('distance');
  text(k/2,D(k),['minD=',num2str(D(k))]);
  hold off

  
  
