function mubiao
clc
clear
    out_iter=10;
    in_iter=100;
    x=zeros(out_iter,in_iter);
    a=zeros(out_iter,in_iter);
    b=zeros(out_iter,in_iter);
    c=zeros(out_iter,in_iter);
    f=zeros(out_iter,in_iter);
    k=zeros(out_iter,1);
    for out=1:out_iter
    x(1,1)=-5;
    a(1,1)=x(1,1)^3;
    b(1,1)=3*x(1,1)^2;
    c(1,1)=-9*x(1,1);
    f(1,1)=a(1,1)+b(1,1)+c(1,1);
    k(1)=f(1,1);
    delta=rand*0.1;
    for in=2:in_iter   
        x(out,in)=x(out,in-1)+delta;
        if x(out,in)>=-5 && x(out,in)<=2
        a(out,in)=x(out,in)^3;
        b(out,in)=3*x(out,in)^2;
        c(out,in)=-9*x(out,in);
        else
            delta=-1/2*delta;
            continue
        end
        f(out,in)=a(out,in)+b(out,in)+c(out,in);
        if f(out,in)<f(out,in-1)
            delta=-1/2*delta;
        end
        if in==in_iter
            k(out)=f(out,in_iter);
        end
    end
    if out==out_iter
        [value,index]=max(k);
        plot(f(index,:),'k')
% plot(k(:))
value
        title(['Maximization function']);
%         fprintf('The best X is --->>%5.2f\n',num2str(x(index,in_iter)))
%         fprintf('The best Y is --->>%5.2f\n',num2str(value))
        text(3,-2,['Final search results: maximum ',num2str(value),'�� Corresponding x value�� ',num2str(x(index,in_iter))]);
    end
    
        
    end
    


end