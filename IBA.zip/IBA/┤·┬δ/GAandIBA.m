jiejuGA();
hold on
qianzhipingheng();
hold off