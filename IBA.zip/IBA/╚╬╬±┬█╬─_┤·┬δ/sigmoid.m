close all  
fsigmoid=@(x) 1./(1+exp(-x));  
x=-8:.1:8;  
y=fsigmoid(x);  
  
  
fdy_dz=@(y) y.*(1-y);  
  
  
dsig=fdy_dz(y);  
  
fontSize=20;  
figure(1)
% subplot(121);  
plot(x,y);  
title('sigmoid����','FontSize',fontSize)  
xlabel('x','FontSize',fontSize)  
ylabel('sigmoid(x)','FontSize',fontSize)  
grid on  
% axis equal  
 figure(2) 
% subplot(122);  
plot(x,dsig);  
title('sigmoid�����ĵ���','FontSize',fontSize)  
xlabel('x','FontSize',fontSize)  
ylabel('d sigmoid(x) /dx','FontSize',fontSize)  
grid on  
  
idx=find(mod(x,2)==0)  
for i=1:length(idx)  
    fprintf('x=%2d,\t����ֵΪ��%2.5f,\t����Ϊ��%2.5f\n',x(idx(i)),y(idx(i)),dsig(idx(i)))  
end